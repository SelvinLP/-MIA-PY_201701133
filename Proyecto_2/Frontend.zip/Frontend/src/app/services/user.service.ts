import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { map } from "rxjs/operators";
import { isNullOrUndefined } from 'util';
import { UsersInterface } from '../models/Users-interface';
import { Router } from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient, private router: Router) { }

  headers: HttpHeaders = new HttpHeaders({
    "Content-Type": "application/json"
  })

  //Obtener Usuarios
  GetUsers() {
    const url = "http://localhost:3000/getUsers";
    return this.http.get(url);
  }
  //Crear Usuarios
  AddUsers(Nombre:string,Apellido:string,Contraseña:string,Correo:string,Telefono:string,Fotografia:string,Genero:string,Fecha_Nacimiento:string,Fecha_Registro:String,Direccion:string,Credito_Disponible:string,Ganancia_Obtenida:string,Clase_Cliente:string,Estado:string,Fk_Rol:string){
    const url = "http://localhost:3000/addUsers";
    return this.http.post(
      url,
      {
        "nombres":Nombre,
        "apellidos":Apellido,
        "contraseña":Contraseña,
        "correo":Correo,
        "telefono":Telefono,
        "fotografia":Fotografia,
        "genero":Genero,
        "fecha_nacimiento":Fecha_Nacimiento,
        "fecha_registro":Fecha_Registro,
        "direccion":Direccion,
        "credito_disponible":Credito_Disponible,
        "ganancia_obtenida":Ganancia_Obtenida,
        "clase_cliente":Clase_Cliente,
        "estado":Estado,
        "fk_rol":Fk_Rol
      },
      { headers: this.headers }
    ).pipe(map(data => data));
  }
  //Correo Confirmacion
  sendEmail(Nombre:string,Apellido:string,Contraseña:string,Correo:string,Telefono:string,Fotografia:string,Genero:string,Fecha_Nacimiento:string,Fecha_Registro:String,Direccion:string,Credito_Disponible:string,Ganancia_Obtenida:string,Clase_Cliente:string,Estado:string,Fk_Rol:string) {
    const url = "http://localhost:3000/Sendmail";
    return this.http.post(
      url,
      {
        "nombres":Nombre,
        "apellidos":Apellido,
        "contraseña":Contraseña,
        "correo":Correo,
        "telefono":Telefono,
        "fotografia":Fotografia,
        "genero":Genero,
        "fecha_nacimiento":Fecha_Nacimiento,
        "fecha_registro":Fecha_Registro,
        "direccion":Direccion,
        "credito_disponible":Credito_Disponible,
        "ganancia_obtenida":Ganancia_Obtenida,
        "clase_cliente":Clase_Cliente,
        "estado":Estado,
        "fk_rol":Fk_Rol
      }
    )
  }
  //Permisos Login
  SetCurrentUser(User:UsersInterface) {
    let Nuevo_User = JSON.stringify(User);
    localStorage.setItem('UsuarioLog', Nuevo_User);
  }
  GetCurrentUser() {
    let UsuarioObtenido = localStorage.getItem('UsuarioLog');
    if (!isNullOrUndefined(UsuarioObtenido)) {
      let user_json = JSON.parse(UsuarioObtenido);
      return user_json;
    } else {
      return null;
    }
  }
  Logout() {
    localStorage.removeItem("UsuarioLog");
    this.router.navigate(['']);
  }
  //Permisos para Admin
  SetCurrentAdmin(User:UsersInterface) {
    let Nuevo_User = JSON.stringify(User);
    localStorage.setItem('AdminLog', Nuevo_User);
  }
  GetCurrentAdmin() {
    let UsuarioObtenido = localStorage.getItem('AdminLog');
    if (!isNullOrUndefined(UsuarioObtenido)) {
      let user_json = JSON.parse(UsuarioObtenido);
      return user_json;
    } else {
      return null;
    }
  }
  LogoutAdmin() {
    localStorage.removeItem("AdminLog");
    this.router.navigate(['']);
  }
  //Permisos para Servici de Ayuda
  SetCurrentServicioAyuda(User:UsersInterface) {
    let Nuevo_User = JSON.stringify(User);
    localStorage.setItem('AyudaLog', Nuevo_User);
  }
  GetCurrentServicioAyuda() {
    let UsuarioObtenido = localStorage.getItem('AyudaLog');
    if (!isNullOrUndefined(UsuarioObtenido)) {
      let user_json = JSON.parse(UsuarioObtenido);
      return user_json;
    } else {
      return null;
    }
  }
  LogoutServicioAyuda() {
    localStorage.removeItem("AyudaLog");
    this.router.navigate(['']);
  }
  //Rcuperacion de Contraseña
  RecupEmail(Contraseña:string,Correo:string) {
    const url = "http://localhost:3000/SendmailRecuperacion";
    return this.http.post(
      url,
      {
        "contraseña":Contraseña,
        "correo":Correo
      }
    )
  }
  //Actualizar Usuario
  UpdateUser(Correo:string,Nombre:string,Apellido:string,Contraseña:string,Telefono:string,Direccion:string){
    const url = "http://localhost:3000/updateUsers";
    return this.http.put(
      url,
      {
        "correo":Correo,
        "nombres":Nombre,
        "apellidos":Apellido,
        "contraseña":Contraseña,
        "telefono":Telefono,
        "direccion":Direccion
      },
      { headers: this.headers }
    ).pipe(map(data => data));
  }
  //Eliminar Usuario
  DeleteUser(Correo:string,Estado:String,Contraseña:string){
      const url = "http://localhost:3000/deleteUsers";
      return this.http.put(
        url,
        {
          "correo":Correo,
          "estado":Estado,
          "password":Contraseña
        },
        { headers: this.headers }
      ).pipe(map(data => data));
  }
  //Modificar Cuenta desde admin
  UpdateCuenta(Correo:string,Nombre:string,Apellido:string,Contraseña:string,Telefono:string,Direccion:string,Genero:string,Fecha_Nacimiento:string,Rol:string){
    const url = "http://localhost:3000/updateUsersAdmin";
    return this.http.put(
      url,
      {
        "correo":Correo,
        "nombres":Nombre,
        "apellidos":Apellido,
        "contraseña":Contraseña,
        "telefono":Telefono,
        "direccion":Direccion,
        "genero":Genero,
        "fecha_nacimiento":Fecha_Nacimiento,
        "rol":Rol
      },
      { headers: this.headers }
    ).pipe(map(data => data));
  }
  //Agregar a Bitacora
  AddBitacora(Usuario:string,Fecha:string,Contenido:string){
    const url = "http://localhost:3000/addBitacora";
    return this.http.post(
      url,
      {
        "usuario":Usuario,
        "fecha":Fecha,
        "contenido":Contenido
      },
      { headers: this.headers }
    ).pipe(map(data => data));

  }
  //Obtener Bitacora
  GetBitacora() {
    const url = "http://localhost:3000/getBitacora";
    return this.http.get(url);
  }
  //Calificacion de Servicio
  AddCalificacionS( Id_Usuario:string,Calificacion:string,Descripcion:String){
    const url = "http://localhost:3000/addCalificacionServicio";
    return this.http.post(
      url,
      {
        "Id_Usuario":Id_Usuario,
        "Calificacion": Calificacion,
        "Descripcion": Descripcion
      },
      { headers: this.headers }
    ).pipe(map(data => data));

  }
  //Obtener Calificacion de Servicio
  GetCalificacionS() {
    const url = "http://localhost:3000/getCalificacionServicio";
    return this.http.get(url);
  }

  //CATEGORIAS
  addCategoria(Nombre:string,Descripcion:string,Estado:string,Fk_Categoria:string){
    const url = "http://localhost:3000/addCategoria";
    return this.http.post(
      url,
      {
        "nombre":Nombre,
        "descripcion": Descripcion,
        "estado": Estado,
        "fk_categoria": Fk_Categoria
      },
      { headers: this.headers }
    ).pipe(map(data => data));
  }
  updateCategoria(Id_Categoria:string,Nombre:string,Descripcion:string,Estado:string,Fk_Categoria:string){
    const url = "http://localhost:3000/updateCategoria";
    return this.http.put(
      url,
      {
        "id_categoria":Id_Categoria,
        "nombre":Nombre,
        "descripcion": Descripcion,
        "estado": Estado,
        "fk_categoria": Fk_Categoria
      },
      { headers: this.headers }
    ).pipe(map(data => data));
  }
  GetCategoria() {
    const url = "http://localhost:3000/getCategoria";
    return this.http.get(url);
  }

  //Productos
  addProducto( Imagen:string,Descripcion_P:String,Id_Categoria_P:String,Precio:String,Fecha:String,Cantidad:string,Cantidad_Disponible:String,Color:String,id_usuario:string){
    const url = "http://localhost:3000/addProducto";
    return this.http.post(
      url,
      {
        "imagen":Imagen,
        "descripcion":Descripcion_P,
        "id_categoria":Id_Categoria_P,
        "precio":Precio,
        "fecha":Fecha,
        "cantidad":Cantidad,
        "cantidaddisponible":Cantidad_Disponible,
        "color":Color,
        "id_usuario":id_usuario
      },
      { headers: this.headers }
    ).pipe(map(data => data));
  }
  updateProducto(Descripcion_P:String,Id_Categoria_P:String,Precio:String,Fecha:String,Cantidad:string,Cantidad_Disponible:String,Color:String,Id_Producto:string){
    const url = "http://localhost:3000/updateProducto";
    return this.http.put(
      url,
      {
        "descripcion":Descripcion_P,
        "id_categoria":Id_Categoria_P,
        "precio":Precio,
        "fecha":Fecha,
        "cantidad":Cantidad,
        "cantidaddisponible":Cantidad_Disponible,
        "color":Color,
        "id_producto":Id_Producto
      },
      { headers: this.headers }
    ).pipe(map(data => data));
  }
  GetProducto() {
    const url = "http://localhost:3000/getProducto";
    return this.http.get(url);
  }
  //Imagen
  addFile(formData) {
    let urlAPI = 'http://localhost:3000/api/upload';
    return this.http.post(urlAPI, formData);
  }
  //Comentario
  AddComentario( Id_Producto:string,Calificacion:string,Comentario:String){
    const url = "http://localhost:3000/addComentario";
    return this.http.post(
      url,
      {
        "id_producto":Id_Producto,
        "calificacion":Calificacion,
        "comentario":Comentario
      },
      { headers: this.headers }
    ).pipe(map(data => data));

  }

  //REPORTES
  GetReporte1() {
    const url = "http://localhost:3000/getreporte1";
    return this.http.get(url);
  }
  GetReporte2() {
    const url = "http://localhost:3000/getreporte2";
    return this.http.get(url);
  }
  GetReporte3() {
    const url = "http://localhost:3000/getreporte3";
    return this.http.get(url);
  }
  GetReporte4() {
    const url = "http://localhost:3000/getreporte4";
    return this.http.get(url);
  }
  GetReporte5() {
    const url = "http://localhost:3000/getreporte5";
    return this.http.get(url);
  }
  GetReporte6() {
    const url = "http://localhost:3000/getreporte6";
    return this.http.get(url);
  }
  
}
