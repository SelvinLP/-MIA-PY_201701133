export interface CategoriaSInterface {
    Id_Categoria:string,
    Nombre:string,
    Descripcion:string,
    Estado:string,
    Fk_Categoria:string
}