export interface ProductoInterface {
    Id_Producto:String,
    Imagen:String,
    Descripcion:string,
    Id_Categoria:string,
    Precio:string,
    Fecha:string
    Cantidad:string
    Cantidad_Disponible:String,
    Color:string
}