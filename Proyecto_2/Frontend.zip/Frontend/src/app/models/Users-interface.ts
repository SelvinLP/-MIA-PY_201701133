
export interface UsersInterface {
    Apellido: string,
    Clase_Cliente: string,
    Clave_Acceso: string,
    Correo: string,
    Credito_Disponible: number,
    Direccion: string,
    Estado: string,
    Fotografia: string,
    Ganancia_Obtenida: number,
    Genero: string,
    No_Identificacion: number,
    Nombre: string,
    Telefono: number,
    fecha_Nacimiento: string,
    fecha_Registro: string,
    FK_Rol:string
}