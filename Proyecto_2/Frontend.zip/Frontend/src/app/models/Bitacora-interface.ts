
export interface BitacoraInterface {
    Id:number,
    Usuario: string,
    Fecha: string,
    Contenido: string
}