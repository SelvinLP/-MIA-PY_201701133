export interface CalificacionSInterface {
    Id_Calificacion:string,
    Id_Usuario:string,
    Calificacion:string,
    Descripcion:string
}