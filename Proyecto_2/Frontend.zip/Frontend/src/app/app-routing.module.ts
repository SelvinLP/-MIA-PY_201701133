import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from "./conponents/home/home.component";
import { AuthGuard } from "./guards/auth.guard";
//Usuario
import { CrearUsuarioComponent } from "./conponents/crear-usuario/crear-usuario.component";
import { HomeUserComponent } from "./conponents/home-user/home-user.component";
import { ConfiguracionUsuComponent } from "./conponents/configuracion-usu/configuracion-usu.component";
import { HomeAdminComponent } from './conponents/home-admin/home-admin.component';
import { HomeServicioAyudaComponent } from './conponents/home-servicio-ayuda/home-servicio-ayuda.component';
import { AdminGuard } from './guards/admin.guard';
import { ServicioAyudaGuard } from './guards/servicio-ayuda.guard';
import { ViewBitacoraComponent } from './conponents/view-bitacora/view-bitacora.component';
import { ChatComponent } from './conponents/chat/chat.component';
import { ProductoyCategoriaComponent } from './conponents/productoy-categoria/productoy-categoria.component';
import { ReportesComponent } from './conponents/reportes/reportes.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'crearUsuario',
    component: CrearUsuarioComponent
  },
  {
    path: 'home_user',
    component: HomeUserComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'config_user',
    component: ConfiguracionUsuComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'home_admin',
    component: HomeAdminComponent,
    canActivate: [AdminGuard]
  },
  {
    path: 'home_servicioayuda',
    component: HomeServicioAyudaComponent,
    canActivate: [ServicioAyudaGuard]
  },
  {
    path: 'viewBitacora',
    component: ViewBitacoraComponent,
    canActivate: [AdminGuard]
  },
  {
    path: 'chat',
    component: ChatComponent,
    canActivate: [AuthGuard]
  },
  {
    path:"ProdyCat",
    component: ProductoyCategoriaComponent,
    canActivate: [AuthGuard]
  },
  {
    path:"Reportes",
    component :ReportesComponent,
    canActivate:[AdminGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
