import { TestBed } from '@angular/core/testing';

import { ServicioAyudaGuard } from './servicio-ayuda.guard';

describe('ServicioAyudaGuard', () => {
  let guard: ServicioAyudaGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(ServicioAyudaGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
