import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { ChatService } from 'src/app/services/chat.service';
import { UsersInterface } from 'src/app/models/Users-interface';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent implements OnInit {

  constructor(private chatService: ChatService, public router: Router,public UsuService:UserService) { }

  ngOnInit(): void {
    this.chatService.getMessages()
      .subscribe((nuevomessage: string) => {
        console.log(nuevomessage);
        if(this.message==nuevomessage || nuevomessage==null || nuevomessage==""){
          this.message = '';
        }else{
          //agregamos
          var f = new Date();
          let Fecha_Registro=f.getHours()+":"+f.getMinutes();
      
          this.chatService.sendMessage(this.message);
          var CuerpoChat = <HTMLScriptElement>document.getElementById("CuerpoChat");
          var div1 = document.createElement("div");div1.className+="outgoing_msg";div1.style.cssText="overflow:hidden; margin:26px 0 26px;";
          var div2 = document.createElement("div");div2.className+="sent_msg";div2.style.cssText="float: left; width: 46%;";
          var span = document.createElement("span");span.className+="time_date";span.style.cssText="  color: #747474;display: block;font-size: 12px;margin: 8px 0 0;";
          var Cuerpo = document.createTextNode(""+nuevomessage);var Cuerp2 = document.createTextNode(Fecha_Registro+" | Hoy");
          div2.appendChild(Cuerpo);
          span.appendChild(Cuerp2);div2.appendChild(span);
          div1.appendChild(div2);
          CuerpoChat.appendChild(div1);

        }
      });
  }

  Regresar(){
    this.router.navigate(['/home_user']);
    var calificacion = prompt("Califique el Nivel de Servicio","10-0");
    let Datos_U:UsersInterface=this.UsuService.GetCurrentServicioAyuda();
    //insertamos la Calificacion
    if(calificacion!=null){
      this.UsuService.AddCalificacionS(Datos_U.No_Identificacion.toString(),calificacion,"Servicio de Ayuda")
      .subscribe((res)=>{
      })
    }
  }
  //websockets
  message: string;
  sendMessage() {
    //obtener fecha
    var f = new Date();
    let Fecha_Registro=f.getHours()+":"+f.getMinutes();

    var CuerpoChat = <HTMLScriptElement>document.getElementById("CuerpoChat");
    var div1 = document.createElement("div");div1.className+="outgoing_msg";div1.style.cssText="overflow:hidden; margin:26px 0 26px;";
    var div2 = document.createElement("div");div2.className+="sent_msg";div2.style.cssText="float: right; width: 46%;";
    var span = document.createElement("span");span.className+="time_date";span.style.cssText="  color: #747474;display: block;font-size: 12px;margin: 8px 0 0;";
    var Cuerpo = document.createTextNode(""+this.message);var Cuerp2 = document.createTextNode(Fecha_Registro+" | Hoy");
    div2.appendChild(Cuerpo);
    span.appendChild(Cuerp2);div2.appendChild(span);
    div1.appendChild(div2);
    CuerpoChat.appendChild(div1);

    //mandamos el mensaje
    this.chatService.sendMessage(this.message);
  }
}
