import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { UsersInterface } from 'src/app/models/Users-interface';

@Component({
  selector: 'app-home-admin',
  templateUrl: './home-admin.component.html',
  styleUrls: ['./home-admin.component.css']
})
export class HomeAdminComponent implements OnInit {

  constructor(public AdminService: UserService, public router: Router) { 
    this.AdminService.GetUsers().subscribe((res: UsersInterface[])=>{
      this.L_Usuario=res;
      this.Actualizar_Tabla();
    })
  }

  ngOnInit(): void {
  }
  //Datos Usuario
  L_Usuario: UsersInterface[]=[];
  //campos de la variale
  CorreoBusqueda:string="";
  No_Identificacion:string="";
  Nombre:string="";
  Apellido:string="";
  Password:string="";
  Correo:string="";
  Telefono:string="";
  Fotografia:string="";
  Genero:string="";
  Fecha_Nacimiento:string="";
  Fecha_Registro:string="";
  Direccion:string="";
  Credito_Disponible:string="";
  Ganancia_Obtenida:string="";
  Clase:string="";
  Fk_Rol:string="";

  CerrarSesion(){
    this.AdminService.LogoutAdmin();
    this.router.navigate(['']);
  }
    //Limpiar
    Limpiar(){
      this.No_Identificacion="";
      this.Nombre="";
      this.Apellido="";
      this.Password="";
      this.Correo="";
      this.Telefono="";
      this.Genero="";
      this.Fecha_Nacimiento="";
      this.Direccion="";
      this.Clase="";
      this.Fk_Rol="";
    }
    //Actualizar Tabla
    Actualizar_Tabla(){
      //Agregar a Tabla
      var ttabla = <HTMLScriptElement>document.getElementById("tablaVar");
      try {
          ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
      } catch (error) {}
      
      var tblBody = document.createElement("tbody");
      for(let posv=0;posv<this.L_Usuario.length;posv++){
        if(this.L_Usuario[posv].Estado!="Eliminado"){
          var hilera = document.createElement("tr");
          //Id
          var celda = document.createElement("td");
          var textoCelda = document.createTextNode(""+this.L_Usuario[posv].No_Identificacion);
          celda.appendChild(textoCelda);hilera.appendChild(celda);
          //Nombre
          var celda = document.createElement("td");
          var textoCelda = document.createTextNode(""+this.L_Usuario[posv].Nombre);
          celda.appendChild(textoCelda);hilera.appendChild(celda);   
          //Apellido
          var celda = document.createElement("td");
          var textoCelda = document.createTextNode(""+this.L_Usuario[posv].Apellido);
          celda.appendChild(textoCelda);hilera.appendChild(celda); 
          //Contraseña
          var celda = document.createElement("td");
          var textoCelda = document.createTextNode(""+this.L_Usuario[posv].Clave_Acceso);
          celda.appendChild(textoCelda);hilera.appendChild(celda); 
          //Correo
          var celda = document.createElement("td");
          var textoCelda = document.createTextNode(""+this.L_Usuario[posv].Correo);
          celda.appendChild(textoCelda);hilera.appendChild(celda); 
          //Tipo
          let Tipo="";
          if(this.L_Usuario[posv].FK_Rol=="1"){
            Tipo="Administrador";
          }else if(this.L_Usuario[posv].FK_Rol=="2"){
            Tipo="Servicio de Ayuda";
          }else if(this.L_Usuario[posv].FK_Rol=="3"){
            Tipo="Cliente";
          }
          var celda = document.createElement("td");
          var textoCelda = document.createTextNode(""+Tipo);
          celda.appendChild(textoCelda);hilera.appendChild(celda); 
    
          tblBody.appendChild(hilera);
        }
      }
      ttabla.appendChild(tblBody);
    }
    //Busqueda
    Buscar(){
      let bandera=false;
      for(let pos=0;pos<this.L_Usuario.length;pos++){
        if(this.L_Usuario[pos].Correo==this.CorreoBusqueda && this.L_Usuario[pos].Estado!="Eliminado"){
          //Agregamos campos
          this.Nombre=this.L_Usuario[pos].Nombre;
          this.Apellido=this.L_Usuario[pos].Apellido;
          this.Password=this.L_Usuario[pos].Clave_Acceso;
          this.Correo=this.L_Usuario[pos].Correo;
          this.Telefono=this.L_Usuario[pos].Telefono.toString();
          this.Fecha_Nacimiento=this.L_Usuario[pos].fecha_Nacimiento;
          this.Direccion=this.L_Usuario[pos].Direccion;
          this.Fk_Rol=this.L_Usuario[pos].FK_Rol;
          this.Genero=this.L_Usuario[pos].Genero;
          bandera=true;
          break;
        }
      }
      if(bandera==false){
        alert("El correo no existe");
      }
    }
    //Crear
    CrearUsuario(){
      let bandera=true;
      //validacion Contraseña
      if(this.Password.length>=8){
        let Mayuscula=0;let Miniscula=0;let Digito=0;let Simbolos=0;
        for(let pos=0;pos<this.Password.length;pos++){
          if(this.Password.charAt(pos).match(/[a-z]/)){
            Miniscula=1;
          }else if(this.Password.charAt(pos).match(/[A-Z]/)){
            Mayuscula=1;
          }else if(this.Password.charAt(pos).match(/\d/)){
            Digito=1;
          }else if(this.Password.charAt(pos).match(/[\s]/)){
          }else{Simbolos=1;}
        }
        if(Mayuscula==0 || Miniscula==0 || Digito==0 || Simbolos==0){
          alert("La Contraseña de Tener como minimo una Miniscula,Mayuscula,Digito o Simbolo"); 
          bandera=false;
        }
      }else{alert("La contrasña debe ser mayor o igual a 8 Caracteres");bandera=false;}
      //Validacion de Correo
      var regex_Correo = /^[^@]+@[^@]+\.[a-zA-Z]{2,}$/g
      if(regex_Correo.test(this.Correo)){
  
      }else{
        alert("Ingrese un Correo Valido");
        bandera=false; 
      }
  
      if(bandera==true){//Envia el correo 
        //Agregar Campo Adicioneales
        var f = new Date();
        this.Fecha_Registro=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
        //Asignacion de Clas Cliente y Credito
        let Valor_R=Math.floor(Math.random() * 5) + 1;
        if(Valor_R==1){this.Clase="Diamante";this.Credito_Disponible="5000"}
        if(Valor_R==2){this.Clase="Platino";this.Credito_Disponible="25000"}
        if(Valor_R==3){this.Clase="Oro";this.Credito_Disponible="10000"}
        if(Valor_R==4){this.Clase="Plata";this.Credito_Disponible="5000"}
        if(Valor_R==5){this.Clase="Bronce";this.Credito_Disponible="1000"}
  
        this.AdminService.sendEmail(this.Nombre,this.Apellido,this.Password,this.Correo,this.Telefono,this.Fotografia,this.Genero,this.Fecha_Nacimiento,this.Fecha_Registro,this.Direccion,this.Credito_Disponible,this.Ganancia_Obtenida,this.Clase,"Desconectado",this.Fk_Rol)
        .subscribe((res: UsersInterface[])=>{
          this.L_Usuario=res;
          alert("Se ha enviado el Correo Correctamente");
          //Agregar a Bitacora
          var f = new Date();
          let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();

          let Tipo_Usu;
          if(this.Fk_Rol=="1"){
            Tipo_Usu="Administrador";
          }else if(this.Fk_Rol=="2"){
            Tipo_Usu="Servicio de Ayuda";
          }else if(this.Fk_Rol=="3"){
            Tipo_Usu="Cliente";
          }
          this.AdminService.AddBitacora("Administrador",Fecha,"Se Creado Un "+Tipo_Usu+" con el Nombre: "+this.Nombre)
          .subscribe((res: UsersInterface[])=>{})
        })
        this.Limpiar();
      }  
    }
    //Modificar 
    ModificarUsuario(){
      this.AdminService.UpdateCuenta(this.Correo,this.Nombre,this.Apellido,this.Password,this.Telefono,this.Direccion,this.Genero,this.Fecha_Nacimiento,this.Fk_Rol)
        .subscribe((res: UsersInterface[])=>{
          this.L_Usuario=res;
          alert("Se ha enviado el Correo Correctamente");
          //Agregar a Bitacora
          var f = new Date();
          let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
          let Tipo_Usu;
          if(this.Fk_Rol=="1"){
            Tipo_Usu="Administrador";
          }else if(this.Fk_Rol=="2"){
            Tipo_Usu="Servicio de Ayuda";
          }else if(this.Fk_Rol=="3"){
            Tipo_Usu="Cliente";
          }
          this.AdminService.AddBitacora("Administrador",Fecha,"Se Modifico Un "+Tipo_Usu+" llamado: "+this.Nombre)
          .subscribe((res: UsersInterface[])=>{})
          this.Limpiar();
      })
    }
    //Eliminar
    EliminarUsuario(){
      this.AdminService.DeleteUser(this.Correo,"Eliminado",this.Password)
      .subscribe((res: UsersInterface[])=>{})
      alert("Se ha Eliminado Correctamente");
      //Agregar a Bitacora
      var f = new Date();
      let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
      let Tipo_Usu;
      if(this.Fk_Rol=="1"){
        Tipo_Usu="Administrador";
      }else if(this.Fk_Rol=="2"){
        Tipo_Usu="Servicio de Ayuda";
      }else if(this.Fk_Rol=="3"){
        Tipo_Usu="Cliente";
      }
      this.AdminService.AddBitacora("Administrador",Fecha,"Se Elimino un "+Tipo_Usu+" llamado: "+this.Nombre)
      .subscribe((res: UsersInterface[])=>{})

      this.Limpiar();
    }
    //Bloquear
    BloquearUsuario(){
      this.AdminService.DeleteUser(this.Correo,"Eliminado",this.Password)
      .subscribe((res: UsersInterface[])=>{})
      alert("Se ha Bloqueado Correctamente");
      //Agregar a Bitacora
      var f = new Date();
      let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
      let Tipo_Usu;
      if(this.Fk_Rol=="1"){
        Tipo_Usu="Administrador";
      }else if(this.Fk_Rol=="2"){
        Tipo_Usu="Servicio de Ayuda";
      }else if(this.Fk_Rol=="3"){
        Tipo_Usu="Cliente";
      }
      this.AdminService.AddBitacora("Administrador",Fecha,"Se Bloqueado un "+Tipo_Usu+" llamado: "+this.Nombre)
      .subscribe((res: UsersInterface[])=>{})

      this.Limpiar();
    }
    //Bitacora
    Bitacora(){
      this.router.navigate(['/viewBitacora']);
    }
    //REPORTES
    Reportes(){
      this.router.navigate(['/Reportes']);
    }
}
