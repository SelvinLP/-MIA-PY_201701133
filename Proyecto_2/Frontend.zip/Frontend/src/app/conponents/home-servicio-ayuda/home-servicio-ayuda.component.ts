import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { ChatService } from 'src/app/services/chat.service';
import { UsersInterface } from 'src/app/models/Users-interface';

@Component({
  selector: 'app-home-servicio-ayuda',
  templateUrl: './home-servicio-ayuda.component.html',
  styleUrls: ['./home-servicio-ayuda.component.css']
})
export class HomeServicioAyudaComponent implements OnInit {

  constructor(public router: Router,public ServicioAyudaService:UserService,private chatService: ChatService) { 
    this.Usuarios=[];
    let Datos_U:UsersInterface=this.ServicioAyudaService.GetCurrentUser();
    this.Usuarios.push(Datos_U.Nombre);
  }

  ngOnInit(): void {
    this.chatService.getMessages()
    .subscribe((nuevomessage: string) => {
      console.log(nuevomessage);
      if(this.message==nuevomessage || nuevomessage==null || nuevomessage==""){
        this.message = '';
      }else{
        //agregamos
        var f = new Date();
        let Fecha_Registro=f.getHours()+":"+f.getMinutes();
    
        this.chatService.sendMessage(this.message);
        var CuerpoChat = <HTMLScriptElement>document.getElementById("CuerpoChat");
        var div1 = document.createElement("div");div1.className+="outgoing_msg";div1.style.cssText="overflow:hidden; margin:26px 0 26px;";
        var div2 = document.createElement("div");div2.className+="sent_msg";div2.style.cssText="float: left; width: 46%;";
        var span = document.createElement("span");span.className+="time_date";span.style.cssText="  color: #747474;display: block;font-size: 12px;margin: 8px 0 0;";
        var Cuerpo = document.createTextNode(""+nuevomessage);var Cuerp2 = document.createTextNode(Fecha_Registro+" | Hoy");
        div2.appendChild(Cuerpo);
        span.appendChild(Cuerp2);div2.appendChild(span);
        div1.appendChild(div2);
        CuerpoChat.appendChild(div1);

      }
    });
  }

  CerrarSesion(){
    this.ServicioAyudaService.LogoutServicioAyuda();
    this.router.navigate(['']);
  }
    //websockets
    message: string;
    Usuarios: string[] = [];
    sendMessage() {
      //obtener fecha
      var f = new Date();
      let Fecha_Registro=f.getHours()+":"+f.getMinutes();
  
      var CuerpoChat = <HTMLScriptElement>document.getElementById("CuerpoChat");
      var div1 = document.createElement("div");div1.className+="outgoing_msg";div1.style.cssText="overflow:hidden; margin:26px 0 26px;";
      var div2 = document.createElement("div");div2.className+="sent_msg";div2.style.cssText="float: right; width: 46%;";
      var span = document.createElement("span");span.className+="time_date";span.style.cssText="  color: #747474;display: block;font-size: 12px;margin: 8px 0 0;";
      var Cuerpo = document.createTextNode(""+this.message);var Cuerp2 = document.createTextNode(Fecha_Registro+" | Hoy");
      div2.appendChild(Cuerpo);
      span.appendChild(Cuerp2);div2.appendChild(span);
      div1.appendChild(div2);
      CuerpoChat.appendChild(div1);
  
      //mandamos el mensaje
      this.chatService.sendMessage(this.message);
    }
}
