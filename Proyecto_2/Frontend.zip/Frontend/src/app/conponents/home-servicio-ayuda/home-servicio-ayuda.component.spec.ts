import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeServicioAyudaComponent } from './home-servicio-ayuda.component';

describe('HomeServicioAyudaComponent', () => {
  let component: HomeServicioAyudaComponent;
  let fixture: ComponentFixture<HomeServicioAyudaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeServicioAyudaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeServicioAyudaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
