import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { UserService } from "../../services/user.service";
import { UsersInterface } from "../../models/Users-interface";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(public router: Router,public UsuService:UserService) {
  }

  ngOnInit(): void {
  }
  //Datos Usuario
  L_Usuario: UsersInterface[]=[];
  //Datos
  Nombre:string="";
  Password:string="";

  //Fucion Para Crear Usuario
  Ev_CrearUsuario(){
    this.router.navigate(['/crearUsuario']);
  }

  //Funcion para login
  Ev_Login(){
      //Obtener Usuarios
      this.UsuService.GetUsers().subscribe((res: UsersInterface[])=>{
        this.L_Usuario=res;
        let Encontrado=false;let EncontradoPass=false;
        for(let pos=0;pos<this.L_Usuario.length;pos++){
          if(this.L_Usuario[pos].Correo==this.Nombre && this.L_Usuario[pos].Estado!="Eliminado"){
            Encontrado=true;
            if(this.L_Usuario[pos].Clave_Acceso==this.Password){
              EncontradoPass=true;
              //si es usuario
              if(this.L_Usuario[pos].FK_Rol=="3"){
                this.UsuService.SetCurrentUser(this.L_Usuario[pos]);
                this.router.navigate(['/home_user']);
              }else if(this.L_Usuario[pos].FK_Rol=="1"){//si es admin
                this.UsuService.SetCurrentAdmin(this.L_Usuario[pos]);
                this.router.navigate(['/home_admin']);
              }else if(this.L_Usuario[pos].FK_Rol=="2"){//si es Service Ayuda
                this.UsuService.SetCurrentServicioAyuda(this.L_Usuario[pos]);
                this.router.navigate(['/home_servicioayuda']);
              }
              break;
            }
          }
        }
        if(Encontrado==false){
          alert("Usuario No Registrado");
        }
      })
  }

  //Fucion Recuperar Contraseña 
  Ev_RecuperarUsu(){
    let Correo=prompt("Ingrese Correo del Usuario","");
    if(Correo.length!=0){
      //generacion de correo aleatorio
      let NuevaPass="Pass_"+Math.floor(Math.random() * 9) + 1;+Math.floor(Math.random() * 9) + 1;
      NuevaPass+=Math.floor(Math.random() * 9) + 1;
      this.UsuService.RecupEmail(NuevaPass,Correo)
      .subscribe((res: UsersInterface[])=>{
      })
      alert("El Correo se ha enviado Correctamente");
      //Agregar a Bitacora
      var f = new Date();
      let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
      this.UsuService.AddBitacora("Sistema",Fecha,"Se Solicitado Recuperacion de Contraseña al Correo"+Correo)
      .subscribe((res: UsersInterface[])=>{})
    }else{
      alert("El Correo no existe");
    }
  }

}
