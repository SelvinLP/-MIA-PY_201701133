import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { UsersInterface } from 'src/app/models/Users-interface';
import { CategoriaSInterface } from 'src/app/models/Categoria-interface';
import { ProductoInterface } from 'src/app/models/Producto-interface';

@Component({
  selector: 'app-productoy-categoria',
  templateUrl: './productoy-categoria.component.html',
  styleUrls: ['./productoy-categoria.component.css']
})
export class ProductoyCategoriaComponent implements OnInit {

  constructor(public ConfCatyPService: UserService,public router: Router) { 
    //Categorias
    this.ConfCatyPService.GetCategoria().subscribe((res:CategoriaSInterface[])=>{
      this.L_Categoria=res;
      this.Actualizar_Tabla();
    })
    //Productos
    this.ConfCatyPService.GetProducto().subscribe((res:ProductoInterface[])=>{
      this.L_Productos=res;
      this.Actualizar_TablaP();
    })
    
  }
  ngOnInit(): void {
  }
  //Datos
  Regresar(){
    this.router.navigate(['/home_user']);
  }
  //Categoria
  L_Categoria: CategoriaSInterface[]=[];
  Nombre="";
  Descripcion="";
  Estado="";
  Categoria="";
  Id_Categoria="";
  //Actualizar Tabla
  Actualizar_Tabla(){
    //Agregar a Tabla
    var ttabla = <HTMLScriptElement>document.getElementById("tablaVar");
    try {
        ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
    } catch (error) {}
    
    var tblBody = document.createElement("tbody");
    for(let posv=0;posv<this.L_Categoria.length;posv++){
      if(this.L_Categoria[posv].Estado!="No Disponible"){
        var hilera = document.createElement("tr");
        //Id
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Categoria[posv].Id_Categoria);
        celda.appendChild(textoCelda);hilera.appendChild(celda);
        //Nombre
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Categoria[posv].Nombre);
        celda.appendChild(textoCelda);hilera.appendChild(celda);   
        //Descripcion
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Categoria[posv].Descripcion);
        celda.appendChild(textoCelda);hilera.appendChild(celda); 
  
        tblBody.appendChild(hilera);
      }
    }
    ttabla.appendChild(tblBody);
  }
  Limpiar(){
    this.Nombre="";
    this.Descripcion="";
    this.Estado="";
    this.Categoria="";
    this.Id_Categoria="";
  }
  AddCategoria(){
    this.ConfCatyPService.addCategoria(this.Nombre,this.Descripcion,"Disponible",this.Categoria)
    .subscribe((res)=>{
    })
    //Agregar a Bitacora
    let Datos_U:UsersInterface=this.ConfCatyPService.GetCurrentUser();
    var f = new Date();
    let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
    this.ConfCatyPService.AddBitacora(Datos_U.Nombre,Fecha,"A agregado una Categoria")
    .subscribe((res)=>{})

    this.Limpiar();
  }
  putCategoria(){
    let Datos_U:UsersInterface=this.ConfCatyPService.GetCurrentUser();
    this.ConfCatyPService.updateCategoria(this.Id_Categoria,this.Nombre,this.Descripcion,"Disponible",this.Categoria)
    .subscribe((res)=>{
    })

    //Agregar a Bitacora
    var f = new Date();
    let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
    this.ConfCatyPService.AddBitacora(Datos_U.Nombre,Fecha,"A modificado una Categoria")
    .subscribe((res)=>{})

    this.Limpiar();
  }
  deleteCategoria(){
    let Datos_U:UsersInterface=this.ConfCatyPService.GetCurrentUser();
    this.ConfCatyPService.updateCategoria(this.Id_Categoria,this.Nombre,this.Descripcion,"No Disponible",this.Categoria)
    .subscribe((res)=>{
    })

    //Agregar a Bitacora
    var f = new Date();
    let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
    this.ConfCatyPService.AddBitacora(Datos_U.Nombre,Fecha,"A Eliminado una Categoria")
    .subscribe((res)=>{})

    this.Limpiar();
  }
  Buscar(){
    for(let pos=0;pos<this.L_Categoria.length;pos++){
      if(this.L_Categoria[pos].Id_Categoria==this.Id_Categoria && this.L_Categoria[pos].Estado!="No Disponible"){
        this.Nombre=this.L_Categoria[pos].Nombre;
        this.Descripcion=this.L_Categoria[pos].Descripcion;
        this.Estado=this.L_Categoria[pos].Estado;
        this.Categoria=this.L_Categoria[pos].Fk_Categoria;
      }
    }

  }

  //Producto
  L_Productos:ProductoInterface[]=[];
  Id_Producto:string;
  Imagen:string;
  Descripcion_P:String;
  Id_Categoria_P:String;
  Precio:String;
  Fecha:string;
  Cantidad:string;
  Cantidad_Disponible:String;
  Color:String;
  Valoracion:String;
  Actualizar_TablaP(){
      //Agregar a Tabla
      var ttabla = <HTMLScriptElement>document.getElementById("tablaP");
      try {
          ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
      } catch (error) {}
      
      var tblBody = document.createElement("tbody");
      for(let posv=0;posv<this.L_Productos.length;posv++){
        if(this.L_Productos[posv].Descripcion!="Eliminado"){
          var hilera = document.createElement("tr");
          //Id
          var celda = document.createElement("td");
          var textoCelda = document.createTextNode(""+this.L_Productos[posv].Id_Producto);
          celda.appendChild(textoCelda);hilera.appendChild(celda);
          //Descripcion
          var celda = document.createElement("td");
          var textoCelda = document.createTextNode(""+this.L_Productos[posv].Descripcion);
          celda.appendChild(textoCelda);hilera.appendChild(celda)   
          //Categoria
          var celda = document.createElement("td");
          var textoCelda = document.createTextNode(""+this.L_Productos[posv].Id_Categoria);
          celda.appendChild(textoCelda);hilera.appendChild(celda)
          //Precio
          var celda = document.createElement("td");
          var textoCelda = document.createTextNode(""+this.L_Productos[posv].Precio);
          celda.appendChild(textoCelda);hilera.appendChild(celda)
          //Cantidad Disponible
          var celda = document.createElement("td");
          var textoCelda = document.createTextNode(""+this.L_Productos[posv].Cantidad_Disponible);
          celda.appendChild(textoCelda);hilera.appendChild(celda)
          //Color
          var celda = document.createElement("td");
          var textoCelda = document.createTextNode(""+this.L_Productos[posv].Color);
          celda.appendChild(textoCelda);hilera.appendChild(celda)

          tblBody.appendChild(hilera);
        }
      }
      ttabla.appendChild(tblBody);
  }
  addProducto(){
    //Agregar a Bitacora
    let Datos_U:UsersInterface=this.ConfCatyPService.GetCurrentUser();
    var f = new Date();
    let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
    this.ConfCatyPService.AddBitacora(Datos_U.Nombre,Fecha,"A agregado un Producto")
    .subscribe((res)=>{})

    this.ConfCatyPService.addProducto(this.Imagen,this.Descripcion_P,this.Id_Categoria_P,this.Precio,Fecha,this.Cantidad,this.Cantidad,this.Color,Datos_U.No_Identificacion.toString())
    .subscribe((res)=>{
    })

    this.LimpiarP();
  }
  updateProducto(){
    //Agregar a Bitacora
    let Datos_U:UsersInterface=this.ConfCatyPService.GetCurrentUser();
    var f = new Date();
    let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
    this.ConfCatyPService.AddBitacora(Datos_U.Nombre,Fecha,"A Modificado un Producto")
    .subscribe((res)=>{})
    
    this.ConfCatyPService.updateProducto(this.Descripcion_P,this.Id_Categoria_P,this.Precio,Fecha,this.Cantidad,this.Cantidad,this.Color,this.Id_Producto)
    .subscribe((res)=>{
    })
    
    this.LimpiarP();
  }
  deleteProducto(){
    //Agregar a Bitacora
    let Datos_U:UsersInterface=this.ConfCatyPService.GetCurrentUser();
    var f = new Date();
    let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
    this.ConfCatyPService.AddBitacora(Datos_U.Nombre,Fecha,"A Modificado un Producto")
    .subscribe((res)=>{})
        
    this.ConfCatyPService.updateProducto("Eliminado",this.Id_Categoria_P,this.Precio,Fecha,this.Cantidad,this.Cantidad,this.Color,this.Id_Producto)
    .subscribe((res)=>{
    })
        
    this.LimpiarP();
  }
  BuscarP(){
    for(let pos=0;pos<this.L_Productos.length;pos++){
      if(this.L_Productos[pos].Id_Producto==this.Id_Producto &&this.L_Productos[pos].Descripcion!="Eliminado"){
        this.Descripcion_P=this.Imagen=this.L_Productos[pos].Descripcion;
        this.Id_Categoria_P=this.Imagen=this.L_Productos[pos].Id_Categoria;
        this.Precio=this.Imagen=this.L_Productos[pos].Precio;
        this.Fecha=this.L_Productos[pos].Fecha;
        this.Cantidad=this.L_Productos[pos].Cantidad;
        this.Cantidad_Disponible=this.L_Productos[pos].Cantidad_Disponible;
        this.Color=this.L_Productos[pos].Color;
      }
    }
  }
  LimpiarP(){
    this.Id_Producto="";
    this.Imagen="";
    this.Descripcion_P="";
    this.Id_Categoria_P="";
    this.Precio="";
    this.Cantidad="";
    this.Cantidad_Disponible="";
    this.Color="";
  }

    //CargaMasiva
  fileContent;

  public onChange(fileList: FileList): void {
    let file = fileList[0];
    let fileReader: FileReader = new FileReader();
    let self = this;
    fileReader.onloadend = function(x) {
      self.fileContent = fileReader.result;
    }
    fileReader.readAsText(file);
  }
  InsertarCarga(){
    let Datos_U:UsersInterface=this.ConfCatyPService.GetCurrentUser();
    let contenido=this.fileContent;
    //Insertamos Cada elemento
    let Cambio=0;let Codigo;let Nobre; let Precio; let Categoria;let Color;let Cantidad;let tem="";
    for(let pos=0;pos<contenido.toString().length;pos++){
      if(contenido.charAt(pos).charCodeAt(0)==44 || contenido.charAt(pos)=='\n'){
        if(Cambio==0){
          Codigo=tem;Cambio++;
        }else if(Cambio==1){
          Nobre=tem;Cambio++;
        }else if(Cambio==2){
          Precio=tem;Cambio++;
        }else if(Cambio==3){
          Categoria=tem;Cambio++;
        }else if(Cambio==4){
          Color=tem;Cambio++;
        }else if(Cambio==5){
          Cantidad=tem;
          Cambio=0;
          //Busqueda de Categoria
          let L_Cat: CategoriaSInterface[]=[];
          let Id_Categoria="-1";
          this.ConfCatyPService.GetCategoria().subscribe((res:CategoriaSInterface[])=>{
            L_Cat=res;
            //Agregamos Categoria
            for(let pos2=0;pos2<L_Cat.length;pos2++){
              if(L_Cat[pos2].Nombre==Categoria){
                Id_Categoria=""+L_Cat[pos2].Id_Categoria;
                break;
              }
            }
          })
          
          if(Id_Categoria=="-1"){
            this.ConfCatyPService.addCategoria(Categoria,"Por Carga Masiva","Disponible","-1")
            .subscribe((res)=>{
            })
          }

          //insertamos
          var f = new Date();
          let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
          this.ConfCatyPService.addProducto(" ",Nobre,Id_Categoria,Precio,Fecha,Cantidad,Cantidad,Color,Datos_U.No_Identificacion.toString())
          .subscribe((res)=>{
          })
        }
        tem="";
      }else{
        tem+=contenido.charAt(pos);
      }
    }
    alert("Se ha Cargado Correctaente");
    //Insertamos en Bitacora
    var f = new Date();
    let Fecha=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
    this.ConfCatyPService.AddBitacora(Datos_U.Nombre,Fecha,"A realizado una Carga Masiva")
    .subscribe((res)=>{})

  }

    //Para Cargar Imagen
    fileContent2:File;
  public onChange2(fileList: FileList): void {
      this.fileContent2=fileList[0];
      //Cargar Imagen
      let fd=new  FormData();
      fd.append('image',this.fileContent2,this.fileContent2.name);
      this.ConfCatyPService.addFile(fd).subscribe((res:{"message":string})=> {
        this.Imagen=res.message.toString();
      });
  }
}
