import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductoyCategoriaComponent } from './productoy-categoria.component';

describe('ProductoyCategoriaComponent', () => {
  let component: ProductoyCategoriaComponent;
  let fixture: ComponentFixture<ProductoyCategoriaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductoyCategoriaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductoyCategoriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
