import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { UsersInterface } from 'src/app/models/Users-interface';
import { BitacoraInterface } from 'src/app/models/Bitacora-interface';

@Component({
  selector: 'app-view-bitacora',
  templateUrl: './view-bitacora.component.html',
  styleUrls: ['./view-bitacora.component.css']
})
export class ViewBitacoraComponent implements OnInit {

  constructor(public ViewService: UserService, public router: Router) { 
    this.ViewService.GetBitacora().subscribe((res:BitacoraInterface[])=>{
      this.L_Datos=res;
      this.Actualizar_Tabla();
    })
  }
  //Datos
  L_Datos;

  ngOnInit(): void {
  }
  //Regresar
  Regresar(){
    this.router.navigate(['/home_admin']);
  }

  //Actualizar Tabla
  Actualizar_Tabla(){
    //Agregar a Tabla
    var ttabla = <HTMLScriptElement>document.getElementById("tablaBitacora");
    try {
        ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
    } catch (error) {}
    
    var tblBody = document.createElement("tbody");
    for(let posv=0;posv<this.L_Datos.length;posv++){
      var hilera = document.createElement("tr");
      //No
      var celda = document.createElement("td");
      var textoCelda = document.createTextNode(""+(posv+1));
      celda.appendChild(textoCelda);hilera.appendChild(celda);
      //Usuario
      var celda = document.createElement("td");
      var textoCelda = document.createTextNode(""+this.L_Datos[posv].Usuario);
      celda.appendChild(textoCelda);hilera.appendChild(celda);   
      //Fecha
      var celda = document.createElement("td");
      var textoCelda = document.createTextNode(""+this.L_Datos[posv].Fecha);
      celda.appendChild(textoCelda);hilera.appendChild(celda); 
      //Contenido
      var celda = document.createElement("td");
      var textoCelda = document.createTextNode(""+this.L_Datos[posv].Contenido);
      celda.appendChild(textoCelda);hilera.appendChild(celda);

      tblBody.appendChild(hilera);
    }
    ttabla.appendChild(tblBody);
  }
}
