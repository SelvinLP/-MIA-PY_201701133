import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { UsersInterface } from 'src/app/models/Users-interface';
import { ProductoInterface } from 'src/app/models/Producto-interface';

@Component({
  selector: 'app-reportes',
  templateUrl: './reportes.component.html',
  styleUrls: ['./reportes.component.css']
})
export class ReportesComponent implements OnInit {

  constructor(public AdminService: UserService, public router: Router) { 
    this.AdminService.GetUsers().subscribe((res: UsersInterface[])=>{
      this.L_Usuario=res;
    })
    this.AdminService.GetProducto().subscribe((res:ProductoInterface[])=>{
      this.L_Productos=res;
    })

    //Mostramos Tablas
    this.AdminService.GetReporte1().subscribe((res:{"Nombre":string,"Promedio":string}[])=>{
      this.L_Datos=res;
      this.ActualizarTabla1();
    })
    this.AdminService.GetReporte6().subscribe((res:{"Descripcion":string,"Promedio":string}[])=>{
      this.L_Datos=res;
      this.ActualizarTabla2();
    })
    this.AdminService.GetReporte2().subscribe((res:{"Nombre":string,"Count":string}[])=>{
      this.L_Datos=res;
      this.ActualizarTabla3();
    })
    this.AdminService.GetReporte3().subscribe((res:{"Descripcion":string,"Nombre":string}[])=>{
      this.L_Datos=res;
      this.ActualizarTabla4();
    })
    this.AdminService.GetReporte4().subscribe((res:{"Descripcion":string,"Count":string,"Fecha":string}[])=>{
      this.L_Datos=res;
    })
    this.AdminService.GetReporte5().subscribe((res:{"Descripcion":string,"Promedio":string}[])=>{
      this.L_Datos=res;
      this.ActualizarTabla7();
    })

  }

  ngOnInit(): void {
  }

  //Datos
  L_Datos;
  L_Usuario: UsersInterface[]=[];
  L_Productos:ProductoInterface[]=[];
  FechaN="";
  Cant;
  Regresar(){
    this.router.navigate(['/home_admin']);
  }
  //Actualizacion de Tablas
  ActualizarTabla1(){
        //Agregar a Tabla
        var ttabla = <HTMLScriptElement>document.getElementById("tabla1");
        try {
            ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
        } catch (error) {}
        
        var tblBody = document.createElement("tbody");
        for(let posv=0;posv<this.L_Datos.length;posv++){
          if(this.L_Datos[posv].Descripcion!="Eliminado"){
            var hilera = document.createElement("tr");
            //Id
            var celda = document.createElement("td");
            var textoCelda = document.createTextNode(""+this.L_Datos[posv].Nombre);
            celda.appendChild(textoCelda);hilera.appendChild(celda);
            //Descripcion
            var celda = document.createElement("td");
            var textoCelda = document.createTextNode(""+this.L_Datos[posv].Promedio);
            celda.appendChild(textoCelda);hilera.appendChild(celda)   
            tblBody.appendChild(hilera);
          }
        }
        ttabla.appendChild(tblBody);
  }
  //Reporte 2 
  FechaNacimientoDespues(){
    //Agregar a Tabla
    var ttabla = <HTMLScriptElement>document.getElementById("tabla2");
    try {
        ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
    } catch (error) {}
    var año = this.FechaN.split("/", 3);
    var tblBody = document.createElement("tbody");
    for(let posv=0;posv<this.L_Usuario.length;posv++){
      let Añoc=this.L_Usuario[posv].fecha_Nacimiento.split("/", 3);
      if(this.L_Usuario[posv].Estado!="Eliminado" && this.L_Usuario[posv].Genero=="Masculino" && this.L_Usuario[posv].FK_Rol=="2" && Añoc[2]>=año[2]){
        var hilera = document.createElement("tr");
        //Id
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Usuario[posv].Nombre);
        celda.appendChild(textoCelda);hilera.appendChild(celda);
        //Descripcion
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Usuario[posv].Genero);
        celda.appendChild(textoCelda);hilera.appendChild(celda)   
         //Descripcion
         var celda = document.createElement("td");
         var textoCelda = document.createTextNode(""+this.L_Usuario[posv].fecha_Nacimiento);
         celda.appendChild(textoCelda);hilera.appendChild(celda) 

        tblBody.appendChild(hilera);
      }
    }
    ttabla.appendChild(tblBody);
  }
  //Reporte 3
  FechaNacimientoAntes(){
    //Agregar a Tabla
    var ttabla = <HTMLScriptElement>document.getElementById("tabla3");
    try {
        ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
    } catch (error) {}
    var año = this.FechaN.split("/", 3);
    var tblBody = document.createElement("tbody");
    for(let posv=0;posv<this.L_Usuario.length;posv++){
      let Añoc=this.L_Usuario[posv].fecha_Nacimiento.split("/", 3);
      if(this.L_Usuario[posv].Estado!="Eliminado" && this.L_Usuario[posv].Genero=="Femenino" && this.L_Usuario[posv].FK_Rol=="1" && Añoc[2]<=año[2]){
        var hilera = document.createElement("tr");
        //Id
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Usuario[posv].Nombre);
        celda.appendChild(textoCelda);hilera.appendChild(celda);
        //Descripcion
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Usuario[posv].Genero);
        celda.appendChild(textoCelda);hilera.appendChild(celda)   
         //Descripcion
         var celda = document.createElement("td");
         var textoCelda = document.createTextNode(""+this.L_Usuario[posv].fecha_Nacimiento);
         celda.appendChild(textoCelda);hilera.appendChild(celda) 

        tblBody.appendChild(hilera);
      }
    }
    ttabla.appendChild(tblBody);
  }
  //Reporte 4
  ActualizarTabla2(){
    //Agregar a Tabla
    var ttabla = <HTMLScriptElement>document.getElementById("tabla4");
    try {
        ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
    } catch (error) {}
    
    var tblBody = document.createElement("tbody");
    for(let posv=0;posv<this.L_Datos.length;posv++){
      if(this.L_Datos[posv].Descripcion!="Eliminado"){
        var hilera = document.createElement("tr");
        //Id
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Datos[posv].Descripcion);
        celda.appendChild(textoCelda);hilera.appendChild(celda);
        //Descripcion
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Datos[posv].Promedio);
        celda.appendChild(textoCelda);hilera.appendChild(celda)   
        tblBody.appendChild(hilera);
      }
    }
    ttabla.appendChild(tblBody);
  }
  //Reporte 5
  ActualizarTabla3(){
    //Agregar a Tabla
    var ttabla = <HTMLScriptElement>document.getElementById("tabla5");
    try {
        ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
    } catch (error) {}
    
    var tblBody = document.createElement("tbody");
    for(let posv=0;posv<this.L_Datos.length;posv++){
      if(this.L_Datos[posv].Descripcion!="Eliminado"){
        var hilera = document.createElement("tr");
        //Id
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Datos[posv].Nombre);
        celda.appendChild(textoCelda);hilera.appendChild(celda);
        //Descripcion
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Datos[posv].Count);
        celda.appendChild(textoCelda);hilera.appendChild(celda)   
        tblBody.appendChild(hilera);
      }
    }
    ttabla.appendChild(tblBody);
  }
  //Reporte 6
  ActualizarTabla4(){
    //Agregar a Tabla
    var ttabla = <HTMLScriptElement>document.getElementById("tabla6");
    try {
        ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
    } catch (error) {}
    
    var tblBody = document.createElement("tbody");
    for(let posv=0;posv<this.L_Datos.length;posv++){
      if(this.L_Datos[posv].Descripcion!="Eliminado"){
        var hilera = document.createElement("tr");
        //Id
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Datos[posv].Descripcion);
        celda.appendChild(textoCelda);hilera.appendChild(celda);
        //Descripcion
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Datos[posv].Nombre);
        celda.appendChild(textoCelda);hilera.appendChild(celda)   
        tblBody.appendChild(hilera);
      }
    }
    ttabla.appendChild(tblBody);
  }
  //Reporte 7
  ActualizarTabla5(){
    //Agregar a Tabla
    var ttabla = <HTMLScriptElement>document.getElementById("tabla7");
    try {
        ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
    } catch (error) {}
    
    var tblBody = document.createElement("tbody");
    for(let posv=0;posv<this.L_Datos.length;posv++){
      if(this.L_Datos[posv].Descripcion!="Eliminado" && this.L_Datos[posv].Fecha==this.FechaN){
        var hilera = document.createElement("tr");
        //Id
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Datos[posv].Descripcion);
        celda.appendChild(textoCelda);hilera.appendChild(celda);
        //Descripcion
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Datos[posv].Count);
        celda.appendChild(textoCelda);hilera.appendChild(celda);
        //Fecha
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Datos[posv].Fecha);
        celda.appendChild(textoCelda);hilera.appendChild(celda)     
        tblBody.appendChild(hilera);
      }
    }
    ttabla.appendChild(tblBody);
  }
  //Reporte 8
  ActualizarTabla6(){
    //Agregar a Tabla
    var ttabla = <HTMLScriptElement>document.getElementById("tabla8");
    try {
        ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
    } catch (error) {}
    
    var tblBody = document.createElement("tbody");
    for(let posv=0;posv<this.L_Productos.length;posv++){
      if(this.L_Productos[posv].Descripcion!="Eliminado" && this.L_Productos[posv].Cantidad_Disponible==this.Cant){
        var hilera = document.createElement("tr");
        //Id
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Productos[posv].Descripcion);
        celda.appendChild(textoCelda);hilera.appendChild(celda);
        //Descripcion
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Productos[posv].Cantidad_Disponible);
        celda.appendChild(textoCelda);hilera.appendChild(celda);

        tblBody.appendChild(hilera);
      }
    }
    ttabla.appendChild(tblBody);
  }
  //Reporte 9
  ActualizarTabla7(){
    //Agregar a Tabla
    var ttabla = <HTMLScriptElement>document.getElementById("tabla9");
    try {
        ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
    } catch (error) {}
    
    var tblBody = document.createElement("tbody");
    for(let posv=0;posv<this.L_Datos.length;posv++){
      if(this.L_Datos[posv].Descripcion!="Eliminado"){
        var hilera = document.createElement("tr");
        //Id
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Datos[posv].Descripcion);
        celda.appendChild(textoCelda);hilera.appendChild(celda);
        //Descripcion
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Datos[posv].Promedio);
        celda.appendChild(textoCelda);hilera.appendChild(celda);

        tblBody.appendChild(hilera);
      }
    }
    ttabla.appendChild(tblBody);
  }
}
