import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { UsersInterface } from 'src/app/models/Users-interface';
import { CategoriaSInterface } from 'src/app/models/Categoria-interface';
import { ProductoInterface } from 'src/app/models/Producto-interface';

@Component({
  selector: 'app-home-user',
  templateUrl: './home-user.component.html',
  styleUrls: ['./home-user.component.css']
})
export class HomeUserComponent implements OnInit {
  L_Categoria: CategoriaSInterface[]=[];
  L_Productos: ProductoInterface[]=[];
  BusquedaId:String;

  constructor(public HomeService: UserService, public router: Router) { 
    this.HomeService.GetCategoria().subscribe((res:CategoriaSInterface[])=>{
      this.L_Categoria=res;
      this.ActualizarArbol();
    })

    //Productos
    this.HomeService.GetProducto().subscribe((res:ProductoInterface[])=>{
      this.L_Productos=res;
      this.Actualizar_TablaP();
    })
  }

  ngOnInit(): void {
    this.MostrarContenidoTitulo();

    //Tree
    var toggler = document.getElementsByClassName("caret");
    var i;
    for (i = 0; i < toggler.length; i++) {
      toggler[i].addEventListener("click", function() {
        this.parentElement.querySelector(".nested").classList.toggle("active");
        this.classList.toggle("caret-down");
      });
    } 
  }
  //Tabla Productos
  Actualizar_TablaP(){
    //Agregar a Tabla
    var ttabla = <HTMLScriptElement>document.getElementById("tablaP");
    try {
        ttabla.removeChild(ttabla.getElementsByTagName("tbody")[0]);
    } catch (error) {}
    
    var tblBody = document.createElement("tbody");
    for(let posv=0;posv<this.L_Productos.length;posv++){
      if(this.L_Productos[posv].Descripcion!="Eliminado"){
        var hilera = document.createElement("tr");
        //Id
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Productos[posv].Id_Producto);
        celda.appendChild(textoCelda);hilera.appendChild(celda);
        //Descripcion
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Productos[posv].Descripcion);
        celda.appendChild(textoCelda);hilera.appendChild(celda)   
        //Categoria
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Productos[posv].Id_Categoria);
        celda.appendChild(textoCelda);hilera.appendChild(celda)
        //Precio
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Productos[posv].Precio);
        celda.appendChild(textoCelda);hilera.appendChild(celda)
        //Cantidad Disponible
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Productos[posv].Cantidad_Disponible);
        celda.appendChild(textoCelda);hilera.appendChild(celda)
        //Color
        var celda = document.createElement("td");
        var textoCelda = document.createTextNode(""+this.L_Productos[posv].Color);
        celda.appendChild(textoCelda);hilera.appendChild(celda)

        tblBody.appendChild(hilera);
      }
    }
    ttabla.appendChild(tblBody);
}
  //Arbol
  ActualizarArbol(){
    this.L_Categoria
    for(let posv=0;posv<this.L_Categoria.length;posv++){
      if(this.L_Categoria[posv].Estado!="No Disponible"){
        //Agregar a Combobox
        var filtro = <HTMLScriptElement>document.getElementById("filtro");
        var option = document.createElement("option");
        var Tit = document.createTextNode(this.L_Categoria[posv].Nombre);
        option.appendChild(Tit);
        filtro.appendChild(option);
        //Agregar a ArboL
        var ttabla = <HTMLScriptElement>document.getElementById(this.L_Categoria[posv].Fk_Categoria);
        var li = document.createElement("li");
        var ul = document.createElement("ul");ul.id=this.L_Categoria[posv].Id_Categoria;
        var span = document.createElement("span");span.className="caret";span.style.cssText="cursor: pointer;user-select: none;   content: \"\\25B6\";color: black;display: inline-block;margin-right: 6px;"
        var Titulo = document.createTextNode(this.L_Categoria[posv].Nombre);
        span.appendChild(Titulo);
        li.appendChild(span);
        li.appendChild(ul);
        ttabla.appendChild(li);
      }
    }
  }
  MostrarContenidoTitulo(){
    let Datos_U:UsersInterface=this.HomeService.GetCurrentUser();
    var CT_Cuerpo = <HTMLScriptElement>document.getElementById("Cuerpo");
    var CT_h1 = document.createElement("h3");CT_h1.className="text-center";
    var Titulo = document.createTextNode("Bienvenido "+Datos_U.Nombre);
    CT_h1.appendChild(Titulo);
    CT_Cuerpo.appendChild(CT_h1);
    //Imagen
    var splitted = Datos_U.Fotografia.split("/", 5);
    var img=document.createElement("img");img.src="../../../assets/"+splitted[4];
    img.width=100;img.height=100;img.className="center";img.style.cssText="display: block;margin-left: auto;margin-right: auto;";
    CT_Cuerpo.appendChild(img);
  }
  CerrarSesion(){
    this.HomeService.Logout();
    this.router.navigate(['']);
  }
  Config(){
    this.router.navigate(['/config_user']);
  }
  //Chat
  Chat(){
    this.router.navigate(['/chat']);
  }
  //Configuracion Producto y Categoria
  ProductoyCategoria(){
    this.router.navigate(['/ProdyCat']);
  }

  //Datos
  Id_Producto:string;
  Imagen:string;
  Descripcion_P:String;
  Id_Categoria_P:String;
  Precio:String;
  Fecha:string;
  Cantidad:string;
  Cantidad_Disponible:String;
  Color:String;
  Valoracion:string;
  BuscarP(){
    for(let pos=0;pos<this.L_Productos.length;pos++){
      if(this.L_Productos[pos].Id_Producto==this.Id_Producto &&this.L_Productos[pos].Descripcion!="Eliminado"){
        this.Descripcion_P=this.Imagen=this.L_Productos[pos].Descripcion;
        this.Id_Categoria_P=this.Imagen=this.L_Productos[pos].Id_Categoria;
        this.Precio=this.Imagen=this.L_Productos[pos].Precio;
        this.Fecha=this.L_Productos[pos].Fecha;
        this.Cantidad=this.L_Productos[pos].Cantidad;
        this.Cantidad_Disponible=this.L_Productos[pos].Cantidad_Disponible;
        this.Color=this.L_Productos[pos].Color;
        //Cargar Imagen
        var CT_Cuerpo = <HTMLScriptElement>document.getElementById("imagenidP");
        var splitted = this.L_Productos[pos].Imagen.split("/", 5);
        var img=document.createElement("img");img.src="../../../assets/"+splitted[4];
        img.width=300;img.height=300;img.className="center";img.style.cssText="display: block;margin-left: auto;margin-right: auto;";
        CT_Cuerpo.appendChild(img);
      }
    }
  }
  Valorar(){
    let Comentario=prompt("Ingrese un Comentario","");
    this.HomeService.AddComentario(this.Id_Producto,this.Valoracion,Comentario)
    .subscribe((res: UsersInterface[])=>{
    })
  }
}
