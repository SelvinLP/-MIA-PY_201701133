import { Component, OnInit } from '@angular/core';
import { UserService } from "../../services/user.service";
import { UsersInterface } from "../../models/Users-interface";
import { Router } from "@angular/router";

@Component({
  selector: 'app-crear-usuario',
  templateUrl: './crear-usuario.component.html',
  styleUrls: ['./crear-usuario.component.css']
})
export class CrearUsuarioComponent implements OnInit {

  constructor(public router: Router,public UsuService:UserService) {
    this.Limpiar();
   }

  ngOnInit(): void {
  }
  //Datos Usuario
  L_Usuario: UsersInterface[]=[];
  //campos de la variale
  No_Identificacion:string="";
  Nombre:string="";
  Apellido:string="";
  Password:string="";
  Correo:string="";
  Telefono:string="";
  Fotografia:string="";
  Genero:string="";
  Fecha_Nacimiento:string="";
  Fecha_Registro:string="";
  Direccion:string="";
  Credito_Disponible:string="";
  Ganancia_Obtenida:string="";
  Clase:string="";
  Fk_Rol:string="";
  //Crear Usuario
  CrearUsu(){
    this.UsuService.AddUsers(this.Nombre,this.Apellido,this.Password,this.Correo,this.Telefono,this.Fotografia,this.Genero,this.Fecha_Nacimiento,this.Fecha_Registro,this.Direccion,this.Credito_Disponible,this.Ganancia_Obtenida,this.Clase,"Desconectado","3")
    .subscribe((res: UsersInterface[])=>{
      this.L_Usuario=res;
    })
    this.Limpiar();
    alert("Se ha registrado Correctamente");
  }
  //Obtener Usuarios
  ObtenerUsu(){
    this.UsuService.GetUsers().subscribe((res: UsersInterface[])=>{
      this.L_Usuario=res;
    })
  }
  //Confirmacion por Correo
  register() {
    let bandera=true;
    //validacion Contraseña
    if(this.Password.length>=8){
      let Mayuscula=0;let Miniscula=0;let Digito=0;let Simbolos=0;
      for(let pos=0;pos<this.Password.length;pos++){
        if(this.Password.charAt(pos).match(/[a-z]/)){
          Miniscula=1;
        }else if(this.Password.charAt(pos).match(/[A-Z]/)){
          Mayuscula=1;
        }else if(this.Password.charAt(pos).match(/\d/)){
          Digito=1;
        }else if(this.Password.charAt(pos).match(/[\s]/)){
        }else{Simbolos=1;}
      }
      if(Mayuscula==0 || Miniscula==0 || Digito==0 || Simbolos==0){
        alert("La Contraseña de Tener como minimo una Miniscula,Mayuscula,Digito o Simbolo"); 
        bandera=false;
      }
    }else{alert("La contrasña debe ser mayor o igual a 8 Caracteres");bandera=false;}
    //Validacion de Correo
    var regex_Correo = /^[^@]+@[^@]+\.[a-zA-Z]{2,}$/g
    if(regex_Correo.test(this.Correo)){

    }else{
      alert("Ingrese un Correo Valido");
      bandera=false; 
    }

    if(bandera==true){//Envia el correo 
      //Agregar Campo Adicioneales
      var f = new Date();
      this.Fecha_Registro=f.getDate() + "/" + (f.getMonth() +1) + "/" + f.getFullYear();
      //Asignacion de Clas Cliente y Credito
      let Valor_R=Math.floor(Math.random() * 5) + 1;
      if(Valor_R==1){this.Clase="Diamante";this.Credito_Disponible="5000"}
      if(Valor_R==2){this.Clase="Platino";this.Credito_Disponible="25000"}
      if(Valor_R==3){this.Clase="Oro";this.Credito_Disponible="10000"}
      if(Valor_R==4){this.Clase="Plata";this.Credito_Disponible="5000"}
      if(Valor_R==5){this.Clase="Bronce";this.Credito_Disponible="1000"}

      this.UsuService.sendEmail(this.Nombre,this.Apellido,this.Password,this.Correo,this.Telefono,this.Fotografia,this.Genero,this.Fecha_Nacimiento,this.Fecha_Registro,this.Direccion,this.Credito_Disponible,this.Ganancia_Obtenida,this.Clase,"Desconectado","3")
      .subscribe((res: UsersInterface[])=>{
        this.L_Usuario=res;
      })
      alert("Se ha enviado el Correo Correctamente para confirmacion");
      
      this.router.navigate(['']);
    }

    
  }
  //Limpiar
  Limpiar(){
    this.No_Identificacion="";
    this.Nombre="";
    this.Apellido="";
    this.Password="";
    this.Correo="";
    this.Telefono="";
    this.Genero="";
    this.Fecha_Nacimiento="";
    this.Direccion="";
    this.Clase="";
    this.Fk_Rol="";
  }

  //Para Cargar Imagen
  fileContent:File;

  public onChange(fileList: FileList): void {
    this.fileContent=fileList[0];
    //Cargar Imagen
    let fd=new  FormData();
    fd.append('image',this.fileContent,this.fileContent.name);
    this.UsuService.addFile(fd).subscribe((res:{"message":string})=> {
      this.Fotografia=res.message.toString();
    });
  }
}
